use capstone;


#  1. Top Goal Scorers
SELECT player_name_x, SUM(goals) AS total_goals
FROM football_data
GROUP BY player_name_x
ORDER BY total_goals DESC
LIMIT 10;

#  2. Attendance Trend by Season
SELECT season, SUM(attendance) AS total_attendance
FROM football_data
GROUP BY season
ORDER BY season;

#  3. Yellow and Red Cards by Referee
SELECT referee, SUM(yellow_cards) AS total_yellow_cards, SUM(red_cards) AS total_red_cards
FROM football_data
GROUP BY referee
ORDER BY total_yellow_cards DESC, total_red_cards DESC
LIMIT 10;

# 4. Team Performance: Home vs Away 
SELECT 
    home_club_name AS team, 
    SUM(home_club_goals) AS home_goals, 
    SUM(away_club_goals) AS away_goals
FROM football_data
GROUP BY home_club_name
ORDER BY home_goals DESC;


# 5. Cards Distribution Across Seasons
SELECT season, SUM(yellow_cards) AS total_yellow_cards, SUM(red_cards) AS total_red_cards
FROM football_data
GROUP BY season
ORDER BY season;

# 6. Domestic vs International Competitions

SELECT competition_type, SUM(goals) AS total_goals
FROM football_data
GROUP BY competition_type
ORDER BY total_goals DESC;
